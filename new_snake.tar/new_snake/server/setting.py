
db_ip = '127.0.0.1'
db_port = 3306
db_user = 'root'
db_password = '123456'

server_ip = '127.0.0.1'
server_port = 8796

recv_max_bytes = 4096 * 4

redis_db_ip = '127.0.0.1'
redis_db_port = 6379
redis_db_num = 0




